/* 
   UniSysDB library
   Copyright (C) 2011 

   class BIOPAX

   Author: Natapol Pornputtapong <natapol@chalmers.se>
*/


#include "biopax.h"

// tag class
namespace unisys {
	Tag::Tag()
	{
	
	}
	
	Tag::Tag(XMLNode const& node)
	{
		Tag::name = node.getName();
//		boost::to_lower(Tag::name);
//		boost::erase_all(Tag::name, "-");
		if (node.getAttribute("rdf:resource")) {
			Tag::dataType = "";
			Tag::value = node.getAttribute("rdf:resource");
			if (Tag::value[0] == '#') Tag::value.erase(0,1);
		} else {
			Tag::dataType = node.getAttribute("rdf:datatype");
			
			if(node.getText())
				Tag::value = node.getText();
			else
				Tag::value = "";
		}
	}
	
	void Tag::printData() const
	{
		std::cout << Tag::name << " " << Tag::dataType << " " << Tag::value << std::endl;
	}
	
	std::string Tag::getName() const
	{
		return Tag::name;
	}
	
	std::string Tag::getDataType() const
	{
		return Tag::dataType;
	}
	
	std::string Tag::getValue() const
	{
		return Tag::value;
	}
	
	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
	
	BIOPAX_obj::BIOPAX_obj()
	{
	
	}
	
	BIOPAX_obj::BIOPAX_obj(XMLNode const& node)
	{
		BIOPAX_obj::type = node.getName();
//		boost::to_lower(BIOPAX_obj::type);
		if (node.getAttribute("rdf:about"))
			BIOPAX_obj::id = node.getAttribute("rdf:about");
		else
			BIOPAX_obj::id = node.getAttribute("rdf:ID");
		
		for (int i = 0; i < node.nChildNode(); i++) {
			Tag tmpTag(node.getChildNode(i));
			BIOPAX_obj::properties.push_back(tmpTag);
		}
	}
	
	std::string BIOPAX_obj::getId() const
	{
		return BIOPAX_obj::id;
	}

	std::string BIOPAX_obj::getType() const
	{
		return BIOPAX_obj::type;
	}
	
	std::vector<Tag> BIOPAX_obj::getProperties() const
	{
		return BIOPAX_obj::properties;
	}
	
	std::vector<Tag> BIOPAX_obj::getProperties(std::string names) const
	{
		std::set<string> strs;
		boost::algorithm::split(strs, names, boost::algorithm::is_any_of(","));
		
		std::vector<Tag>::const_iterator it;
		std::vector<Tag> tmpVec;
		for (it = BIOPAX_obj::properties.begin(); it != BIOPAX_obj::properties.end(); it++) {
			if ( strs.find((*it).getName()) != strs.end() ) {
				tmpVec.push_back(*it);
			}
		}
		return tmpVec;
	}
	
	Tag BIOPAX_obj::getFirstProperties(std::string name) const
	{
		std::vector<Tag>::const_iterator it;
		Tag tmpTag;
		for (it = BIOPAX_obj::properties.begin(); it != BIOPAX_obj::properties.end(); it++) {
			if ( name.compare((*it).getName()) == 0 ) {
				tmpTag = *it;
				break;
			}
		}
		return tmpTag;
	}
	
	bool BIOPAX_obj::hasProperties(std::string name) const
	{
		std::vector<Tag>::const_iterator it;
		bool tmpBool = false;
		for (it = BIOPAX_obj::properties.begin(); it != BIOPAX_obj::properties.end(); it++) {
			if ( name.compare((*it).getName()) == 0 ) {
				tmpBool = true;
				break;
			}
		}
		return tmpBool;
	}
	
	std::vector<Tag>::const_iterator BIOPAX_obj::begin() const
	{
		return BIOPAX_obj::properties.begin();
	}
	
	std::vector<Tag>::const_iterator BIOPAX_obj::end() const
	{
		return BIOPAX_obj::properties.end();
	}
	
	void BIOPAX_obj::printData() const
	{
		std::cout << BIOPAX_obj::type << " " << BIOPAX_obj::id << std::endl;
		std::vector<Tag>::const_iterator it;
		for (it = BIOPAX_obj::properties.begin(); it != BIOPAX_obj::properties.end(); it++)
			(*it).printData();
		
	}
	
	void BIOPAX_obj::printData(std::string name) const
	{
		std::cout << BIOPAX_obj::type << " " << BIOPAX_obj::id << std::endl;
		std::vector<Tag> tmpProp = BIOPAX_obj::getProperties(name);
		
		std::vector<Tag>::const_iterator it;
		for (it = tmpProp.begin(); it != tmpProp.end(); it++)
			(*it).printData();
	}
	
	void BIOPAX_obj::printTagName() const
	{
		std::cout << BIOPAX_obj::type << " " << BIOPAX_obj::id << std::endl;
		std::vector<Tag>::const_iterator it;
		for (it = BIOPAX_obj::properties.begin(); it != BIOPAX_obj::properties.end(); it++)
			std::cout << (*it).getName() << std::endl;
	}
	
	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
	BIOPAX2::BIOPAX2()
	{
		
	}
	
	BIOPAX2::BIOPAX2(std::string fileName)
	{
		XMLNode xMainNode = XMLNode::openFileHelper(fileName.c_str(), "rdf:RDF");
		BIOPAX2::rdfMainNode = XMLNode::createXMLTopNode("rdf:RDF");
		
		for (int i = 0; i < xMainNode.nAttribute(); i++)
			BIOPAX2::rdfMainNode.addAttribute(xMainNode.getAttributeName(i), xMainNode.getAttributeValue(i));
		
		for (int i = 0; i < xMainNode.nChildNode(); i++) {
			XMLNode tmpNode = xMainNode.getChildNode(i);
			if (strcmp("owl:Ontology", tmpNode.getName()) == 0)
				BIOPAX2::owlNode = tmpNode;
			else {
				BIOPAX_obj tmpBioObj(tmpNode);
				BIOPAX2::objects.insert(std::pair<std::string, BIOPAX_obj>(tmpBioObj.getId(), tmpBioObj));
			}
		}
	}
	
	XMLNode BIOPAX2::getRDFMainNode() const
	{
		return BIOPAX2::rdfMainNode;
	}
	
	XMLNode BIOPAX2::getOWLNode() const
	{
		return BIOPAX2::owlNode;
	}
	
	BIOPAX_obj BIOPAX2::getObjectsByID(std::string id) const
	{
		if ( BIOPAX2::objects.find(id) != BIOPAX2::objects.end() ) {
			return BIOPAX2::objects.find(id)->second;
		} else {
			return BIOPAX_obj();
		}
	}
	
//	std::set< std::map<std::string, std::string> > BIOPAX2::getXrefByID(std::string id) const
//	{
//		std::set< std::map<std::string, std::string> > result;
//		
//		// get object from object id
//		unisys::BIOPAX_obj biopaxObj = BIOPAX2::getObjectsByID(id);
//		
//		std::vector<unisys::Tag> xrefVec = biopaxObj.getProperties("bp:xref");
//		std::vector<unisys::Tag>::const_iterator xrefCit;
//		
//		for (xrefCit = xrefVec.begin(); xrefCit != xrefVec.end(); xrefCit++) {
//			std::map<std::string, std::string> id;
//			unisys::BIOPAX_obj xrefBiopaxObj = BIOPAX2::getObjectsByID( (*xrefCit).getValue() );
//			id["db"] = xrefBiopaxObj.getFirstProperties("bp:db").getValue();
//			id["id"] = xrefBiopaxObj.getFirstProperties("bp:id").getValue();
//			if ( xrefBiopaxObj.hasProperties("bp:idversion") ) {
//				id["idversion"] = xrefBiopaxObj.getFirstProperties("bp:idversion").getValue();
//			}
//			result.insert(id);
//		}
//		return result;
//	}
	
	XMLNode BIOPAX2::getParticipantByID(std::string id) const
	{
		XMLNode result = XMLNode::createXMLTopNode("participant");
		
		// get object from object id
		
		
		
		return result;
	}
	
	BIOPAX2::biopaxObjMap::const_iterator BIOPAX2::begin() const
	{
		return BIOPAX2::objects.begin();
	}
	
	BIOPAX2::biopaxObjMap::const_iterator BIOPAX2::end() const
	{
		return BIOPAX2::objects.end();
	}
	
	void BIOPAX2::printObjId() const
	{
		std::map <std::string, BIOPAX_obj>::const_iterator it;
		
		for (it = BIOPAX2::objects.begin(); it != BIOPAX2::objects.end(); it++) {
			BIOPAX_obj tmpBioObj = it->second;
			std::cout << it->first << " " << tmpBioObj.getType() << std::endl;
		}
	}
	
	void BIOPAX2::printData() const
	{
		std::map <std::string, BIOPAX_obj>::const_iterator it;
		
		for (it = BIOPAX2::objects.begin(); it != BIOPAX2::objects.end(); it++) {
			BIOPAX_obj tmpBioObj = it->second;
			tmpBioObj.printData();
		}
	}
	
	void BIOPAX2::printAllTagName() const
	{
		std::map <std::string, BIOPAX_obj>::const_iterator it;
		
		for (it = BIOPAX2::objects.begin(); it != BIOPAX2::objects.end(); it++) {
			BIOPAX_obj tmpBioObj = it->second;
			tmpBioObj.printTagName();
		}
	}
}
//////////g++ biopax.cpp xmlParser.cpp -I/data/Projects/UniSysDBLib/trunk -I/usr/include/mongo -lboost_system -o test
//int main () {
//	unisys::BIOPAX abc("../sample/Homo sapiens.owl");
//	unisys::BIOPAX2::biopaxObjMap::const_iterator cit;
//	unisys::BIOPAX_obj tmpBIOPAXObj = abc.getObjectsByID("PublicationXref3183");
//	std::cout << tmpBIOPAXObj.getType() << std::endl;
//	tmpBIOPAXObj.printTagName();
//	std::cout << std::endl;
//	
////	for (cit = abc.begin(); cit != abc.end(); cit++) {
////		std::cout << cit->second.getType() << std::endl;
////		cit->second.printTagName();
////		std::cout << std::endl;
//////		if (!cit->second.getProperties("bp:displayName").empty()) {
//////			unisys::Tag tmpTag = cit->second.getProperties("bp:displayName,bp:left")[0];
//////			std::cout << tmpTag.getDataType() << " " << tmpTag.getValue() << std::endl;
//////			std::cout << std::endl;
//////		}
////	}
//	exit(0);
//}
