/* 
   UniSysDB library
   Copyright (C) 2011 

	Class BIOPAX

   Author: Natapol Pornputtapong <natapol@chalmers.se>
*/

/** \file biopax.h
    \brief It contain BIOPAX class using for parsing 
	OWL (Web Ontology Language) format especially BIOPAX
*/

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string.h>
#include <map>
#include <vector>
#include <boost/algorithm/string/erase.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/case_conv.hpp>
#include <boost/algorithm/string/classification.hpp>
#include "xmlParser.h"
#include "client/dbclient.h"


#ifndef _UNISYSDB_BIOPAX_H_
#define _UNISYSDB_BIOPAX_H_

/** 
    \brief This class is used to parse OWL format

	some description.
*/

namespace unisys {

	/** 
		\brief This class is used to parse OWL format
		
		Data structure using to store information from Tag-Value pair line except; name and id tag
	*/
	class Tag
	{
		private:
			std::string name;
			
			std::string dataType;
			
			std::string value;
		
		public:
			Tag();
			
			Tag(XMLNode const& node);
			
			std::string getName() const;
			
			std::string getDataType() const;
			
			std::string getValue() const;
			
			void printData() const;
	};
	
	/** 
		\brief This class is used to parse OWL format
		
		some description.
	*/
	class BIOPAX_obj
	{
		private:
		
			std::string type; ///< Type of object
			
			std::string id; ///< ID string of object
			
			std::vector<Tag> properties;
		
		public:
		
			BIOPAX_obj(); ///< Defualt constructor
			
			BIOPAX_obj(XMLNode const& node);
			
			std::string getId() const;
			
			std::string getType() const;
			
			std::vector<Tag> getProperties() const;
			
			std::vector<Tag> getProperties(std::string names) const;
			
			Tag getFirstProperties(std::string name) const;
			
			bool hasProperties(std::string name) const;
			
			std::vector<Tag>::const_iterator begin() const;
			
			std::vector<Tag>::const_iterator end() const;
			
			void printData() const;
			
			void printData(std::string name) const;
			
			void printTagName() const;
	};
	
	/** 
		\brief This class is used to parse OWL format
		
		some description.
	*/
	class BIOPAX2
	{
		private:
		
			XMLNode rdfMainNode; ///< Datamember for storing whole RDF/XML document
			
			XMLNode owlNode; ///< Datamember for storing owl ontology node
			
			std::map<std::string, BIOPAX_obj> objects; ///< All objects map with their ids
		
		public:
			
			typedef std::map<std::string, BIOPAX_obj> biopaxObjMap;
			
			BIOPAX2(); ///< Defualt constructor
			
			BIOPAX2(std::string fileName); ///< Constructor with fileName as parameter
			
			XMLNode getRDFMainNode() const;
			
			XMLNode getOWLNode() const;
			
			BIOPAX_obj getObjectsByID(std::string id) const;
			
			std::set< std::map<std::string, std::string> > getXrefByID(std::string id) const;
			
			std::set< std::map<std::string, std::string> > getParticipantByID(std::string id) const
			
			biopaxObjMap::const_iterator begin() const;
			
			biopaxObjMap::const_iterator end() const;
			
			void printObjId() const;
			
			void printData() const;
			
			void printAllTagName() const;
	};
}
#endif
