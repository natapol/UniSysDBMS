/* 
   UniSysDB library
   Copyright (C) 2011 

   class OBOXML

   Author: Natapol Pornputtapong <natapol@chalmers.se>
*/

#include "updater.h"

namespace unisys {
	
	std::vector<mongo::BSONObj> BatchInsert::rheaBiochemicalReaction(BIOPAX2 const& biopax, std::string idNS, int startId, bool dryrun) throw (UpdateError, DataError)
	{
		std::vector<mongo::BSONObj> tmpVec;
		
		if (idNS.at(idNS.length() - 1) != ':') idNS.append(":");
		
		std::string primeDbURN = "urn:miriam:rhea:";
		
		BIOPAX2::biopaxObjMap::const_iterator mapIt;
		
		for (mapIt = biopax.begin(); mapIt != biopax.end(); mapIt++) {
			if ( mapIt->second.getType().compare("biochemicalReaction") ) {
				
				BiochemicalReaction tmpBiReact;
//				tmpBiReact.setId();
				tmpBiReact.setDataPrimarySource(Xref(primeDbURN + mapIt->second.getPropertyValue("rdf:about")));
				std::vector<std::string> text;
				
				
				for ( int i = 0; i < mapIt->second.nChildNode(); i++ ) {
					if ( strcmp(mapIt->second.getChildNode(i).getName(), "bp:LEFT") == 0 ) {
//						addLeft(PEIdRef & peIdRef, double coefficient);
						
					} else if ( strcmp(mapIt->second.getChildNode(i).getName(), "bp:RIGHT") == 0 ) {
//						addRight(PEIdRef & peIdRef, double coefficient);
						
					} else if ( strcmp(mapIt->second.getChildNode(i).getName(), "bp:NAME") == 0 ) {
						tmpBiReact.setMainName(mapIt->second.getChildNode(i).getText());
					} else if ( strcmp(mapIt->second.getChildNode(i).getName(), "bp:XREF") == 0 ) {
						
						std::string xrefTxt = mapIt->second.getChildNode(i).getText();
						boost::algorithm::replace_first(xrefTxt, "%5B", "_");
						boost::algorithm::replace_last(xrefTxt, "%5D", "");
						boost::algorithm::split(text, xrefTxt, boost::algorithm::is_any_of("_"));
						boost::algorithm::to_lower(text.at(0));
						if (text.size() == 2) {
							if ( text.at(0).compare("bidirectional") == 0 ) {
								OntoRelationship tmpRelationship;
								Miriam reationType("urn:miriam:obo.chebi:" + mapIt->second.getPropertyValue("rdf:about"));
								Miriam relationWith("urn:miriam:obo.chebi:");
								tmpRelationship.setRelationType(OntoIdRef()); // Miriam
								tmpRelationship.setRelationWith(IntIdRef("urn:miriam:rhea:" + )); //Miriam
//								tmpBiReact.addOntoRelationship(tmpRelationship);
							} else if ( text.at(0).compare("undefined") == 0 ) {
//								addOntoRelationship(OntoRelationship & ontorelationship);
							} else if ( text.at(0).compare("left+to+right") == 0 ) {
//								addOntoRelationship(OntoRelationship & ontorelationship);
							} else if ( text.at(0).compare("right+to+left") == 0 ) {
//								addOntoRelationship(OntoRelationship & ontorelationship);
							} else if ( text.at(0).compare("KEGG+reaction") == 0 ) {
								tmpBiReact.addDataXref(Xref("urn:miriam:kegg.reaction:" + text.at(1)));
							} else if ( text.at(0).compare("Rhea") == 0 ) {
								
							} else {
								tmpBiReact.addDataXref(Xref("urn:miriam:un." + text.at(0) + text.at(1)));
							}
							
						}
						
						if ( text.at(0).compare("RHEA:Chemically balanced") == 0 ) {
							if (text.at(1).compare("true") == 0) tmpBiReact.setFunctional();
						} else if ( text.at(0).compare("RHEA:Polymerization") == 0 ) {
							if (text.at(1).compare("true") == 0) tmpBiReact.setFunctional();
						} else if ( text.at(0).compare("RHEA:Direction") == 0 ) {
							if (text.at(1).compare("bidirectional") == 0) {
								tmpBiReact.setConversionDirection("<=>");
							} if (text.at(1).compare("left to right") == 0) {
								tmpBiReact.setConversionDirection("=>");
							} if (text.at(1).compare("undefined") == 0) {
								tmpBiReact.setConversionDirection();
							} 
						}
					} else if ( strcmp(mapIt->second.getChildNode(i).getName(), "bp:EC-NUMBER") == 0 ) {
						tmpBiReact.addDataXref(Xref("urn:miriam:ec-code:" + mapIt->second.getChildNode(i).getText()));
					} else if ( strcmp(mapIt->second.getChildNode(i).getName(), "bp:SPONTANEOUS") == 0 ) {
						tmpBiReact.setSpontaneous()
					} else if ( strcmp(mapIt->second.getChildNode(i).getName(), "bp:COMMENT") == 0 ) {
						std::string commentTxt = mapIt->second.getChildNode(i).getText();
						
						boost::algorithm::split(text, commentTxt, boost::algorithm::is_any_of("="));
						if ( text.at(0).compare("RHEA:Chemically balanced") == 0 ) {
							if (text.at(1).compare("true") == 0) tmpBiReact.setFunctional();
						} else if ( text.at(0).compare("RHEA:Polymerization") == 0 ) {
							if (text.at(1).compare("true") == 0) tmpBiReact.setFunctional();
						} else if ( text.at(0).compare("RHEA:Direction") == 0 ) {
							if (text.at(1).compare("bidirectional") == 0) {
								tmpBiReact.setConversionDirection("<=>");
							} if (text.at(1).compare("left to right") == 0) {
								tmpBiReact.setConversionDirection("=>");
							} if (text.at(1).compare("undefined") == 0) {
								tmpBiReact.setConversionDirection();
							} 
						}
					}
				}
				
			}
		}

//		unisys::BIOPAX2::biopaxObjMap::const_iterator ocit;
//		for (ocit = biopax.begin(); ocit != biopax.end(); ocit++) {
//			if (ocit->second.getType().compare("bp:biochemicalReaction") == 0) {
//			
//				std::vector<unisys::Tag>::const_iterator tcit;
//				std::cout << ocit->second.getId() << std::endl;
//				ocit->second.printData();
//				for (tcit = ocit->second.begin(); tcit != ocit->second.end(); tcit++) {
//					std::string propertyName = (*tcit).getName();
//				
//					if ( propertyName.compare("bp:left") == 0 ) {
//						
//						std::cout << (*tcit).getValue() << std::endl;
//						std::string linkType = (*tcit).getDataType();
//						
//						if ( linkType.compare("bp:smallMolecule") == 0 ) {
//							biopax.getXrefByID( (*tcit).getValue() );
//						} else if ( linkType.compare("bp:protein") == 0 ) {
//							biopax.getXrefByID( (*tcit).getValue() );
//						} else if ( linkType.compare("bp:complex") == 0 ) {
//						
//						}
//					} else if ( propertyName.compare("bp:right") == 0 ) {
//				
//					}
//				
//				}
//			}
//		}
		
//		void addOntoRelationship(OntoRelationship & ontorelationship);
//		
//		void setId(Miriam const& miriam);
//		
//		void setMainName(std::string const& name);
//		
//		void addSynonyms(std::string const& name, std::string const& sep_char = ",");
//		
//		void setComment(std::string const& comment);
//		
//		void setDataPrimarySource(Xref xref);
//		
//		void addAnnotation(Annotation & annotation);
//		
//		void addEvidence(Evidence & evidence);
//		
//		void addDataXref(Xref xref);
//		
//		void addKineticLaw(MathML & kineticLaw);
//		
//		void setSpontaneous(bool value = true);
//		
//		void setFunctional(bool value = true);
//		
//		void setConversionDirection(std::string const& direction = "=");
//		
//		void addLeft(PEIdRef & peIdRef, double coefficient); ///< Add left participants of reaction
//		
//		void addRight(PEIdRef & peIdRef, double coefficient); ///< Add right participants of reaction
		
		return tmpVec;
	}
	
}
//////////g++ biopaxBatchInsert.cpp batchInsert.cpp database.cpp updater*.cpp query.cpp ../parser/biopax*.cpp ../uni/*.cpp ../parser/xmlParser.cpp ../dataclass/*.cpp -lmongoclient -lboost_thread -lboost_filesystem -lboost_date_time -lboost_system -lboost_program_options -I/usr/include/mongo -I/data/Projects/UniSysDBLib/trunk -o test
int main () {
	unisys::Database c;
	c.connect("129.16.106.203");
	unisys::BatchInsert bi(&c);
	
	unisys::BIOPAX2 abc("../sample/Rhea_sample.owl");
	bi.insert(abc, "unisys.interaction", 1,true);
	
	exit(0);
}
