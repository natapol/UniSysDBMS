/* 
   UniSysDB library
   Copyright (C) 2011 

   class OBOXML

   Author: Natapol Pornputtapong <natapol@chalmers.se>
*/


#include "updater.h"

namespace unisys {

	std::vector<mongo::BSONObj> BatchInsert::insert(OBOXML const& oboxml, std::string idNS, int startId, bool dryrun)
	{
		if (idNS.at(idNS.length() - 1) != ':') idNS.append(":");
		std::vector<Stanza>::const_iterator stanzait;
		std::vector<mongo::BSONObj> tmpBSONArray;
		
		for (stanzait = oboxml.stanzasBegin(); stanzait != oboxml.stanzasEnd(); stanzait++) {
			Ontology tmpOnto;
			
			tmpOnto.setId(idNS + (*stanzait).getId());
			tmpOnto.setTerm((*stanzait).getName());
			tmpOnto.setDefinition((*stanzait).getDefinition());
			tmpOnto.setNS((*stanzait).getNS());
			
			// set relationship
			std::map<std::string, std::set<std::string> > relationship = (*stanzait).getRelationship();
			std::map<std::string, std::set<std::string> >::const_iterator subCit;
			std::set<std::string>::const_iterator setCit;
			for (subCit = relationship.begin(); subCit != relationship.end(); subCit++) {
				Miriam reationType(idNS + subCit->first);
				std::set<std::string> relationWiths = subCit->second;
				for (setCit = relationWiths.begin(); setCit != relationWiths.end(); setCit++) {
					Miriam relationWith(idNS + (*setCit));
					OntoRelationship tmpOntoRelationship;
					
					OntoIdRef relationType(reationType.toDBIdWithVer());
					tmpOntoRelationship.setRelationType(relationType); // Miriam
					
					IdRef relatewith(relationWith.toDBIdWithVer(), "ontology");
					tmpOntoRelationship.setRelationWith(relatewith); //Miriam
					
					tmpOnto.addOntoRelationship(tmpOntoRelationship);
				}
			}
			
			
			if (tmpOnto.isValid()) {
				if (dryrun) {
					std::cout << tmpOnto.toString() << std::endl;
				} else {
					Updater::insert(tmpOnto);
				}
			} else {
				tmpBSONArray.push_back(tmpOnto.toBSONObj());
			}
		}
		
		return tmpBSONArray;
		
	}
}

////////g++ database.cpp oboxmlBatchInsert.cpp updater.cpp updaterUpdate.cpp updaterInsert.cpp batchInsert.cpp ../parser/oboXML.cpp ../parser/stanza.cpp ../uni/*.cpp ../parser/xmlParser.cpp ../dataclass/*.cpp -lmongoclient -lboost_thread -lboost_filesystem -lboost_date_time -lboost_system -lboost_program_options -I/usr/include/mongo -I/data/Projects/UniSysDBLib/trunk -o test
//int main () {
//	unisys::Database c;
//	c.connect("129.16.106.203");
//	unisys::BatchInsert bi(&c);
//	unisys::OBOXML oboxml ("../sample/go_daily-termdb.obo-xml");
//	
//	bi.insert(oboxml, "unisys.obo");
//}
