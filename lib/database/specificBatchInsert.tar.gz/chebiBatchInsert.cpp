/* 
   UniSysDB library
   Copyright (C) 2011 

   class OBOXML

   Author: Natapol Pornputtapong <natapol@chalmers.se>
*/

#include "updater.h"

namespace unisys {
	
	std::vector<mongo::BSONObj> BatchInsert::insert(ChEBIOWL const& chebiowl, std::string idNS, int startId, bool dryrun) throw (UpdateError, DataError)
	{
		if (idNS.at(idNS.length() - 1) != ':') idNS.append(":");
		std::vector<ChEBIOWLClass> classList = chebiowl.getClassList();
		std::vector<ChEBIOWLClass>::const_iterator cit;
		
		std::vector<mongo::BSONObj> tmpBSONArray;
		
		int idCounter = startId;
		
		for (cit = classList.begin(); cit != classList.end(); cit++) {
			
			SmallMolecule tmpSmall; // create SmallMolecule instance
			
			char buffer [10];
			sprintf(buffer, "%05d", idCounter);
			std::string instanceId(buffer);
			tmpSmall.setId(Miriam(idNS + instanceId)); // set id of instance
			tmpSmall.setFormula((*cit).getFormula());
			tmpSmall.setInChi((*cit).getInChi());
			tmpSmall.setInChiKey((*cit).getInChiKey());
			tmpSmall.setSMILES((*cit).getSMILES());
			tmpSmall.setMainName((*cit).getLabel());
			
			std::set<std::string> synonym = (*cit).getSpAnnotationProperty("Synonym");
			std::set<std::string>::iterator synit;
			for (synit = synonym.begin(); synit != synonym.end(); synit++) {
				tmpSmall.addSynonyms(*synit);
			}
			
			tmpSmall.setDataPrimarySource(Xref("urn:miriam:obo.chebi:" + (*cit).getId() + "." + chebiowl.getVersion()));
			
			
			// read xref and change id system to miriam format
			std::set<std::string> xrefList = (*cit).getSpAnnotationProperty("xref");
			std::set<std::string>::const_iterator setCit;
			
			for (setCit = xrefList.begin(); setCit != xrefList.end(); setCit++) {
				size_t colonPos = (*setCit).find(":");
				std::string prefix = (*setCit).substr(0, colonPos);
				std::string suffix = (*setCit).substr(colonPos + 1, (*setCit).length() - colonPos - 1);
				if (prefix.compare("ChEMBL") == 0) {
					tmpSmall.addDataXref(Xref("urn:miriam:chembl.compound:" + suffix));
				} else if (prefix.compare("ChemIDplus") == 0) {
					tmpSmall.addDataXref(Xref("urn:miriam:chemidplus:" + suffix));
				} else if (prefix.compare("CiteXplore") == 0) {
					tmpSmall.addDataXref(Xref("urn:miriam:pubmed:" + suffix));
				} else if (prefix.compare("DrugBank") == 0) {
					tmpSmall.addDataXref(Xref("urn:miriam:drugbank:" + suffix));
				} else if (prefix.compare("KEGG COMPOUND") == 0 and suffix.at(0) == 'C') {
					tmpSmall.addDataXref(Xref("urn:miriam:kegg.compound:" + suffix));
				} else if (prefix.compare("KEGG DRUG") == 0) {
					tmpSmall.addDataXref(Xref("urn:miriam:kegg.drug:" + suffix));
				} else if (prefix.compare("KEGG GLYCAN") == 0) {
					tmpSmall.addDataXref(Xref("urn:miriam:kegg.glycan:" + suffix));
				} else if (prefix.compare("LIPID MAPS") == 0) {
					tmpSmall.addDataXref(Xref("urn:miriam:lipidmaps:" + suffix));
				} else if (prefix.compare("MetaCyc") == 0) {
					tmpSmall.addDataXref(Xref("urn:miriam:biocyc:" + suffix));
//				} else if (prefix.compare("NIST Chemistry WebBook") == 0) {
//					tmpSmall.addDataXref(Xref("urn:miriam:chembl.compound:" + suffix));
				} else if (prefix.compare("PDBeChem") == 0) {
					tmpSmall.addDataXref(Xref("urn:miriam:pdb-ccd:" + suffix));
				}
				
			}
			
			
			// set relationship
			std::map<std::string, std::set<std::string> > subClassOf = (*cit).getSubClassOf();
			std::map<std::string, std::set<std::string> >::const_iterator subCit;
			for (subCit = subClassOf.begin(); subCit != subClassOf.end(); subCit++) {
				Miriam reationType("urn:miriam:obo.chebi:" + subCit->first);
				std::set<std::string> relationWiths = subCit->second;
				for (setCit = relationWiths.begin(); setCit != relationWiths.end(); setCit++) {
					Miriam relationWith("urn:miriam:obo.chebi:" + (*setCit) + "." + chebiowl.getVersion());
					OntoRelationship tmpRelationship;
					tmpRelationship.setRelationType(OntoIdRef(reationType.toDBIdWithVer())); // Miriam
					tmpRelationship.setRelationWith(IdRef(relationWith.toDBIdWithVer(), "physicalentity")); //Miriam
					tmpSmall.addOntoRelationship(tmpRelationship);
				}
			}
			
			
			if (tmpSmall.isValid()) {
				if (dryrun) {
					std::cout << tmpSmall.toString() << std::endl;
				} else {
					Updater::insert(tmpSmall);
				}
				idCounter++;
			} else {
				tmpBSONArray.push_back(tmpSmall.toBSONObj());
			}
		}
		
		return tmpBSONArray;
	}
}
///////g++ chebiBatchInsert.cpp batchInsert.cpp database.cpp updater*.cpp query.cpp ../parser/chebio*.cpp ../uni/*.cpp ../parser/xmlParser.cpp ../dataclass/*.cpp -lmongoclient -lboost_thread -lboost_filesystem -lboost_date_time -lboost_system -lboost_program_options -I/usr/include/mongo -I/data/Projects/UniSysDBLib/trunk -o test
int main () {
	unisys::Database c;
	c.connect("129.16.106.203");
	unisys::BatchInsert bi(&c);
	
	unisys::ChEBIOWL tmpChEBI("../samples/chebi.owl");
	bi.insert(tmpChEBI, "unisys.compound", 1,true);
}
