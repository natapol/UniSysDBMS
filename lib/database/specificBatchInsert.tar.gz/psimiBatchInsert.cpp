/*
   UniSysDB library
   Copyright (C) 2011

   Class BatchInsert

   Author: Kwanjeera Wanichthanarak <kwawan@chalmers.se>
*/

#include "updater.h"

namespace unisys{
    /*  Internal function to get miriam URN.  */
    std::string setMiriamURN(std::string db, XMLNode node){
            std::string miriamUrn;
            std::string id = node.getChildNode("xref").getChildNode("primaryRef").getAttribute("id");
            if(db == "psi-mi" || db == "mi"){
                miriamUrn = "urn:miriam:obo.mi:" + id;
            }
            else{
                miriamUrn = "urn:miriam:" + db + ":" + id;
            }
            return miriamUrn;
    }

	std::vector<mongo::BSONObj> BatchInsert::insert(PSIMI const& psimi, std::string idNS, int startId, bool dryrun) throw (UpdateError, DataError){
		if (idNS.at(idNS.length() - 1) != ':') idNS.append(":");
		std::vector<mongo::BSONObj> tmpBSONArray;
		int idCounter = startId;
        std::string dbName = "";
		MolecularInteraction tmpMolInt; //instantiate MolecularInteraction object
		GeneticInteraction tmpGenInt; //instantiate GeneticInteraction object
		XMLNode source = psimi.getNodeSource(); //get 'source' node
        unisys::PSIMI::mapOfXMLNode::iterator it; //iterator index
        unisys::PSIMI::mapOfXMLNode mapContainer; //map container

        mapContainer = psimi.getNodeInteractionList(); //'interactionList' container
        printf("No. of interaction element = %i\n",(int)mapContainer.size()); //get number of 'interaction' element and print

        for (it = mapContainer.begin(); it != mapContainer.end(); it++){
            char buffer [10];
			sprintf(buffer, "%05d", idCounter);
			std::string instanceId(buffer);
			tmpMolInt.setId(Miriam(idNS + instanceId)); //set id of instance
			Xref tmpXref;
            std::cout << "- interaction (id: "<< (*it).first << ") : Data = " << (*it).second.getChildNode("participantList").nChildNode() << std::endl; //print map

            //set dataPrimarySource
            if(!source.getChildNode("xref").isEmpty()){
                dbName = source.getChildNode("xref").getChildNode("primaryRef").getAttribute("db");
                std::cout << setMiriamURN(dbName,source) << std::endl;
                tmpXref = Xref(setMiriamURN(dbName,source));
                tmpMolInt.setDataPrimarySource(tmpXref); //set dataPrimarySource of MolecularInteraction object
            }

            //set dataXref
            if(!(*it).second.getChildNode("xref").isEmpty()){
                dbName = (*it).second.getChildNode("xref").getChildNode("primaryRef").getAttribute("db");
                std::cout << setMiriamURN(dbName,(*it).second) << std::endl;
                tmpXref = Xref(setMiriamURN(dbName,(*it).second));
                tmpMolInt.addDataXref(tmpXref); //set dataXref of MolecularInteraction object
            }
            std::cout << Xref("urn:miriam:obo:12345.234").toString() << std::endl;
            tmpMolInt.setDataPrimarySource(Xref("urn:miriam:obo.chebi:12345.234"));
			std::cout << tmpMolInt.toString() << std::endl;
            //insert
            if (tmpMolInt.isValid()){
                if (dryrun){
                    std::cout << tmpMolInt.toString() << std::endl;
                }
                else{
                    Updater::insert(tmpMolInt);
                }
                idCounter++;
            }
            else{
                tmpBSONArray.push_back(tmpMolInt.toBSONObj());
            }
        }//end for

        return tmpBSONArray;

	}//end function
}
